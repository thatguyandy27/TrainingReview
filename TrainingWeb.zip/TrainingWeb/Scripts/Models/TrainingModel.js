﻿function Training(name, id) {
    this.Name = name;
    this.Id = id;
    this.EmployeeTrainings = [];
}

