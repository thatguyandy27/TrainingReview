﻿function EmployeeTraining(name, id, description, userId, userName, trainingDate, rating) {
    this.Name = name;
    this.Id = id;
    this.Description = description;
    this.UserId = userId;
    this.UserName = userName;
    this.TrainingDate = trainingDate;
    this.Rating = rating;
    this.IsEditable = false;
}